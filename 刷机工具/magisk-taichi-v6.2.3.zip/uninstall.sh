[ -d "/data/system/taichi" ] && rm -rf /data/system/taichi 2>/dev/null
[ -f "/data/misc/taichi" ] && rm -f /data/misc/taichi 2>/dev/null
[ -f "/data/local/tmp/taichi.log" ] && rm -f /data/local/tmp/taichi.log 2>/dev/null